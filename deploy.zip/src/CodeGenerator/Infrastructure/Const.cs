﻿namespace CodeGenerator.Infrastructure;
public class Const
{
    public const string QUERY_STORE = "QueryStore";
    public const string COMMAND_STORE = "CommandStore";
}
