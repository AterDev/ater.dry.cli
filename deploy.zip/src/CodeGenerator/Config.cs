﻿namespace CodeGenerator;

public static class Config
{
    public static string IdType = "Guid";
    public static string CreatedTimeName = "CreatedTime";
    public static readonly string ConfigPath = ".droplet-config.json";

}
