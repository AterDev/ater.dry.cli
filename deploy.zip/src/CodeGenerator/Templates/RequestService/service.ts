﻿import { BaseService, ExtOptions } from './base.service';
[@Import]
class [@ServiceName]Service extends BaseService {
  constructor() {
    super();
  }

[@Functions]
}

export default new [@ServiceName]Service();