# ater.droplet.cli
This is code generator.
Help you generate dtos,datastores,api controllers base on ASP.NET Core project.
It also can help you generate angular interfaces,services and views!

这是一个代码生成器，它可以帮助你生成dto,数据仓储、API控制器，
同时也可以帮助你生成在angular项目中的 ts interfaces，服务以及基本的页面。
