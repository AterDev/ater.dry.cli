﻿namespace CodeGenerator.Test;
public class DocGenerateTest
{

}
