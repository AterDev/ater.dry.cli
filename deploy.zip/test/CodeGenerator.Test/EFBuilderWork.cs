namespace CodeGenerator.Test;
public class EFBuilderWork
{
    [Fact]
    public void Can_get_attributes_from_entity_configuration()
    {

    }

    [Fact]
    public void Can_get_attributes_from_dbcontext()
    {

    }

}
