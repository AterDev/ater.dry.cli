global using System;
global using System.ComponentModel.DataAnnotations;

global using Application.Implement;

global using Ater.Web.Core.Models;
global using Ater.Web.Core.Utils;

global using Entity.CMS;

global using Microsoft.EntityFrameworkCore;
global using Microsoft.Extensions.Logging;
