global using System.Linq.Expressions;

global using Ater.Web.Core.Models;
