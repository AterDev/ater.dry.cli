﻿namespace StandaloneService.Application.Const;
/// <summary>
/// 错误信息
/// </summary>
public static class ErrorMsg
{

}