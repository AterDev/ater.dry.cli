﻿namespace StandaloneService.Application;
public interface IUserContext : IUserContextBase
{
}
