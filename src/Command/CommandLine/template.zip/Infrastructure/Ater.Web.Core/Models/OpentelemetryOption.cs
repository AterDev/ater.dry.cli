﻿namespace Ater.Web.Core.Models;
/// <summary>
/// 遥测选项
/// </summary>
public class OpentelemetryOption
{
    public bool ExportConsole { get; set; }
}
