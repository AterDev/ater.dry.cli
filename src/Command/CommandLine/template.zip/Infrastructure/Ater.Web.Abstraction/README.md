# Intrudction

This class library defines the interface specifications and conventions when using ASP.NET Core and EF Core, like:

- RestControllerBase
- WebAppContext
- IUserContextBase
- ExceptionHandler
- DataAccessContextBase

