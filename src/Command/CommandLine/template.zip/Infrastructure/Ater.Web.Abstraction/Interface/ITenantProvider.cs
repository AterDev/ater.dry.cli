﻿namespace Ater.Web.Abstraction.Interface;
public interface ITenantProvider
{
    public Guid TenantId { get; set; }
}
