global using System.Text;
global using System.Text.Json;
global using Ater.Web.Abstraction;
global using Ater.Web.Core.Utils;
global using Ater.Web.Extension.Services;
global using Microsoft.Extensions.Logging;
